import json
from watson_developer_cloud import ConversationV1
from ay_news_api import *
import pickle
from flask import Flask,render_template,request
app = Flask(__name__)

with open('credentials.json') as js:
    credentials = json.load(js)
    
conversation = ConversationV1(username=str(credentials['username']), password=str(credentials['password']), version='2017-04-21')

workspace_id = '73a74624-91c6-447c-86df-b0a8a3eb6724'

@app.route('/')
def input_display():
    story = {"body" : ''}
    response = ''
    team = ''
    city = ''
    league = ''
    input_text = request.args.get('input')
    days = ''
    entities = []

    if input_text == None or input_text == '':
        return render_template('sports_bot.html', name="I'm the Sports Bot. How can I help?")
        pickle.dump(story,open('story.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(response,open('res.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(team,open('team.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(city,open('city.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(league,open('league.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(days,open('days.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(entitites,open('entities.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
    else:
        output = conv_att(input_text)
        return render_template('sports_bot.html', name=output)

def conv_att(input_text):
    story = {"body" : ''}
    response = ''
    team = ''
    city = ''
    league = ''
    days = ''
    entities = []
    try:
        story = pickle.load(open('story.p','rb'))
        response = pickle.load(open('res.p','rb'))
        team = pickle.load(open('team.p','rb'))
        city = pickle.load(open('city.p','rb'))
        league = pickle.load(open('league.p','rb'))
        days = pickle.load(open('days.p','rb'))
        entities = pickle.load(open('entities.p','rb'))
    except:
        pass
    if "subject" in input_text.lower():
        try:
            return subject
        except:
            return "Subject Unavailable."
    elif "more" in input_text.lower():
        try:
            return story.body
        except:
            return "Story Unavailable."
    elif "source" in input_text.lower():
        try:
            return story.source.name
        except:
            return "Source Unavailable."
    elif "author" in input_text.lower():
        try:
            return story.author.name
        except:
            return "Author Unavailable."
    elif "description" in input_text.lower():
        try:
            if res != '':
                return res
            else:
                return "Description Unavailable."
        except:
            return "Description Unavailable."
    elif 'what about' in input_text.lower():
        watson_response = conversation.message(workspace_id=workspace_id, message_input={'text': input_text.lower().replace('what about','')})# + ' ' + ' '.join(entities)})
        print watson_response
        entities = []
        for i in range(0,len(watson_response['entities'])):
            entity = watson_response['entities'][i]['entity'].replace('-',' ')
            pkeyword = watson_response['entities'][i]['value']
            if 'L_' in entity:
                if len(pkeyword) > len(lookup_str):
                    lookup_str = pkeyword.replace('-',' ')
                    team = pkeyword.split('-')[1]
                    league = entity.split('_')[1]
                    city = pkeyword.split('-')[0]
            elif 'C_' in entity:
                if len(pkeyword) > len(lookup_str):
                    lookup_str = pkeyword.replace('-',' ')
                    team = pkeyword.split('-')[1]
                    city = entity.split('_')[1]
            if entity.split('_')[1] not in entities:
                entities.append(entity.split('_')[1])
        if lookup_str == '':
            lookup_str = input_text
        print team,league,city
        low = int(days.split(',')[0])
        high = int(days.split(',')[1])
        returned = None
        while returned == None:
            days = ','.join([str(low),str(high)])
            returned = ay_lookup(lookup_str, entities=entities, timeframe=days)
            high += 1
        story = returned[0]
        response = returned[1]
        pickle.dump(days,open('days.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(story,open('story.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(response,open('res.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(team,open('team.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(city,open('city.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(league,open('league.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(entities,open('entities.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        return response
    else:
        watson_response = conversation.message(workspace_id=workspace_id, message_input={'text': input_text})
        print watson_response
        entities = []
        lookup_str = ''
        for i in range(0,len(watson_response['entities'])):
            pkeyword = watson_response['entities'][i]['value']
            entity = watson_response['entities'][i]['entity'].replace('-',' ')
            if len(pkeyword) >= len(lookup_str):
                lookup_str = pkeyword.replace('-',' ')
                if 'L_' in entity:
                    league = entity.split('_')[1]
                team = pkeyword.split('-')[1]
                city = pkeyword.split('-')[0]
            if entity.split('_')[1] not in entities:
                entities.append(entity.split('_')[1])
        if lookup_str == '':
            lookup_str = input_text
        print team,league,city
        low = 0
        high = 2
        if 'last week' in input_text.lower():
            low = 6
            high = 13
        if 'last month' in input_text.lower():
            low = 20
            high = 50
        if 'last year' in input_text.lower():
            low = 250
            high = 500
        if 'last night' in input_text.lower():
            low = 0
            high = 1
        returned = None
        while returned == None:
            days = ','.join([str(low),str(high)])
            returned = ay_lookup(lookup_str, entities=entities, timeframe=days)
            high += 1
        story = returned[0]
        response = returned[1]
        pickle.dump(days,open('days.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(story,open('story.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(response,open('res.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(team,open('team.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(city,open('city.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(league,open('league.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(entities,open('entities.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        return response

class info:
    def __init__(this):
        this.last_response = ''
        this.stor = ''
        
app.run()
