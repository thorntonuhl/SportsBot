import json
from watson_developer_cloud import ConversationV1
from ay_news_api import *
import pickle
from flask import Flask,render_template,request
app = Flask(__name__)

with open('credentials.json') as js:
    credentials = json.load(js)
    
conversation = ConversationV1(username=str(credentials['username']), password=str(credentials['password']), version='2017-04-21')

workspace_id = '7659488e-e0f4-4e54-b274-383244bb5f29'

story = {"body" : ''}
watson_response = {}
res = ''
subject = ''


@app.route('/')
def input_display():
    input_text = request.args.get('input')

    if input_text == None or input_text == '':
        return render_template('sports_bot.html', name='I\'m the Sports Bot. How can I help?')
    
    else:
        output = conv_att(input_text)
        return render_template('sports_bot.html', name=output)

def conv_att(input_text):
    try:
        story = pickle.load(open('story.p','rb'))
        res = pickle.load(open('res.p','rb'))
        subject = pickle.load(open('subject.p','rb'))
    except:
        pass
    if "subject" in input_text.lower():
        try:
            return subject
        except:
            return "Subject Unavailable."
    elif "more" in input_text.lower():
        try:
            return story.body
        except:
            return "Story Unavailable."
    elif "source" in input_text.lower():
        try:
            return story.source.name
        except:
            return "Source Unavailable."
    elif "author" in input_text.lower():
        try:
            return story.author.name
        except:
            return "Author Unavailable."
    elif "description" in input_text.lower():
        try:
            if res != '':
                return res
            else:
                return "Description Unavailable."
        except:
            return "Description Unavailable."
    else:
        watson_response = conversation.message(workspace_id=workspace_id, message_input={'text': input_text})
##        print watson_response
        response_message = ''
        entities = []
        oentities = []
        lookup_str = ''
        olookup_str = ''
        for i in range(0,len(watson_response['entities'])):
            pkeyword = watson_response['entities'][i]['entity'].replace('-',' ') + ' ' + watson_response['entities'][i]['value']
            pkey2 = watson_response['entities'][i]['value']
            entity = watson_response['entities'][i]['entity'].replace('-',' ')
            if len(pkey2) > len(olookup_str):
                olookup_str = pkey2
            if len(pkeyword) > len(lookup_str):
                lookup_str = pkeyword
            if pkeyword not in entities:
                entities.append(pkeyword)
            if entity not in oentities:
                oentities.append(entity)
            if pkey2 not in oentities:
                oentities.append(pkey2)
        if lookup_str == '':
            lookup_str = input_text
            olookup_str = input_text
        subject = ''
        for sub in watson_response['intents']:
            if len(sub['intent']) > len(subject):
                subject = sub['intent'].replace('-',' ')
##        print lookup_str,olookup_str,entities,oentities
        low = 0
        high = 2
        if 'last week' in input_text.lower():
            low = 7
            high = 14
        if 'last month' in input_text.lower():
            low = 20
            high = 50
        if 'last year' in input_text.lower():
            low = 250
            high = 500
        if 'last night' in input_text.lower():
            low = 0
            high = 1
        response = None
        counter = 2
        while response == None:
            days = ','.join([str(low),str(high)])
            response = ay_lookup(lookup_str, entities=entities, timeframe=days)
##            print 'keyword1,keywords1'+','+days
            if response == None:
                response = ay_lookup(lookup_str, entities=oentities, timeframe=days)
##                print 'keyword1,keywords2'+','+days
            if response == None:
                response = ay_lookup(olookup_str, entities=oentities, timeframe=days)
##                print 'keyword2,keywords2'+','+days
            high += 1
        story = response[0]
        res = response[1]
        pickle.dump(story,open('story.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(res,open('res.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
        pickle.dump(subject,open('subject.p','wb'),protocol=pickle.HIGHEST_PROTOCOL)
    return res

class info:
    def __init__(this):
        this.last_response = ''
        this.stor = ''
        
app.run()
